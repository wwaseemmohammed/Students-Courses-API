const { Enrollment, Student, Course } = require('../models');

const getAllEnrollments = async (req, res) => {
  try {
    const enrollments = await Enrollment.findAll({
      include: [
        { model: Student, as: 'student' },
        { model: Course, as: 'course' },
      ],
    });
    res.status(200).json(enrollments);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getEnrollmentById = async (req, res) => {
  try {
    const enrollment = await Enrollment.findByPk(req.params.id, {
      include: [
        { model: Student, as: 'student' },
        { model: Course, as: 'course' },
      ],
    });
    if (!enrollment) return res.status(404).json({ message: 'Enrollment not found' });
    res.status(200).json(enrollment);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const createEnrollment = async (req, res) => {
  try {
    const { studentId, courseId, grade } = req.body;

    const student = await Student.findByPk(studentId);
    if (!student) return res.status(404).json({ message: 'Student not found' });

    const course = await Course.findByPk(courseId);
    if (!course) return res.status(404).json({ message: 'Course not found' });

    const existing = await Enrollment.findOne({ where: { studentId, courseId } });
    if (existing) return res.status(400).json({ message: 'Student is already enrolled in this course' });

    const enrollment = await Enrollment.create({ studentId, courseId, grade });
    res.status(201).json(enrollment);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

const updateEnrollment = async (req, res) => {
  try {
    const enrollment = await Enrollment.findByPk(req.params.id);
    if (!enrollment) return res.status(404).json({ message: 'Enrollment not found' });
    const { grade } = req.body;
    await enrollment.update({ grade });
    res.status(200).json(enrollment);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

const deleteEnrollment = async (req, res) => {
  try {
    const enrollment = await Enrollment.findByPk(req.params.id);
    if (!enrollment) return res.status(404).json({ message: 'Enrollment not found' });
    await enrollment.destroy();
    res.status(200).json({ message: 'Enrollment deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAllEnrollments,
  getEnrollmentById,
  createEnrollment,
  updateEnrollment,
  deleteEnrollment,
};
